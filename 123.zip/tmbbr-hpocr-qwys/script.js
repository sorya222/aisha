// دالة لحفظ بيانات المستخدم عند التسجيل
function saveUserData(username, password) {
    localStorage.setItem('username', username);
    localStorage.setItem('password', password);
}

// دالة لتسجيل الدخول
document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();

    // الحصول على البيانات المدخلة من قبل المستخدم
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // التحقق من صحة الاسم وكلمة السر المخزنة
    const storedUsername = localStorage.getItem('username');
    const storedPassword = localStorage.getItem('password');

    if (username === storedUsername && password === storedPassword) {
        // إعادة التوجيه إلى الصفحة الرئيسية (يمكن تعديلها حسب الحاجة)
        window.location.href = 'home.html';
    } else {
        // عرض رسالة خطأ إذا كانت البيانات غير صحيحة
        document.getElementById('errorMessage').style.display = 'block';
        document.getElementById('errorMessage').innerText = 'اسم المستخدم أو كلمة السر غير صحيحة';
    }
});

// دالة لتسجيل مستخدم جديد
document.getElementById('registerForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const newUsername = document.getElementById('newUsername').value;
    const newPassword = document.getElementById('newPassword').value;

    // حفظ بيانات المستخدم الجديد
    saveUserData(newUsername, newPassword);

    // إظهار رسالة تأكيد أو تحويل المستخدم
    alert('تم التسجيل بنجاح! يمكنك الآن تسجيل الدخول.');
});
